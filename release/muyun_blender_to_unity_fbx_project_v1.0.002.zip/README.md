# 木云 Blender 到 Unity FBX 导出插件

版本：1.0  
维护者：muyun  
内部打包编号：1.0.002

## 功能

- 在 Blender 中导出 Unity 友好的 FBX。
- 可选择目标 Unity 版本：自动、2019 LTS、2020 LTS、2021 LTS、2022 LTS、2023 LTS、Unity 6。
- 自动复制材质贴图到 FBX 旁边的 `_Textures` 文件夹。
- 生成 `.muyun_unity.json` 材质清单，记录材质名、基础色、金属度、粗糙度、法线、遮挡、发光和贴图路径。
- 可自动向 Unity 项目的 `Assets/Editor` 写入导入辅助脚本，用于重建 Unity 材质并把 FBX 内的材质名映射到生成的 `.mat`。
- 中文界面，支持文件菜单导出和 3D 视图侧栏快捷导出。

## 安装

在 Blender 中打开“编辑 > 偏好设置 > 插件 > 安装”，选择最终包里的 `muyun_blender_to_unity_fbx_addon_v1.0.xxx.zip`，启用“木云 - Blender 到 Unity FBX”。

## 使用

1. 在 Blender 右侧栏打开“Unity导出”。
2. 选择目标 Unity 版本和 Unity 项目目录，或选择项目内的 `Assets` 目录。
3. 设置导出文件名和范围。
4. 点击“直接导出到 Unity 目录”，或从“文件 > 导出 > 木云 Unity FBX (.fbx)”另存。
5. 在 Unity 中等待资源刷新。导入辅助脚本会在同目录生成 `_Materials` 文件夹并绑定材质贴图。

## 说明

FBX 本身不能完整表达 Blender 的所有节点材质。为最大限度保证 Unity 侧不丢材质贴图，本插件采用三层保护：

- FBX 使用 Unity 友好的坐标、比例、法线和切线设置导出。
- 贴图文件单独复制到 Unity 资源目录，避免嵌入 FBX 后不同 Unity 版本解析差异。
- 生成 Unity 可读的材质清单，并由 `Assets/Editor/MuyunBlenderUnityFbxPostprocessor.cs` 自动创建 `.mat` 和重映射。

复杂节点、程序纹理、未烘焙的几何节点材质仍建议先在 Blender 中烘焙为图片贴图。
